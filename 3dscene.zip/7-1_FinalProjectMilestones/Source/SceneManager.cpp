///////////////////////////////////////////////////////////////////////////////
// SceneManager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//  Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>
#include <iostream>
#include <string>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";

	void SetLightSource(
		ShaderManager* pShaderManager,
		int lightIndex,
		glm::vec3 position,
		glm::vec3 ambientColor,
		glm::vec3 diffuseColor,
		glm::vec3 specularColor,
		float focalStrength,
		float specularIntensity)
	{
		std::string base = "lightSources[" + std::to_string(lightIndex) + "]";

		pShaderManager->setVec3Value(base + ".position", position);
		pShaderManager->setVec3Value(base + ".ambientColor", ambientColor);
		pShaderManager->setVec3Value(base + ".diffuseColor", diffuseColor);
		pShaderManager->setVec3Value(base + ".specularColor", specularColor);
		pShaderManager->setFloatValue(base + ".focalStrength", focalStrength);
		pShaderManager->setFloatValue(base + ".specularIntensity", specularIntensity);
	}

	void SetMaterialValues(
		ShaderManager* pShaderManager,
		glm::vec3 ambientColor,
		float ambientStrength,
		glm::vec3 diffuseColor,
		glm::vec3 specularColor,
		float shininess)
	{
		pShaderManager->setVec3Value("material.ambientColor", ambientColor);
		pShaderManager->setFloatValue("material.ambientStrength", ambientStrength);
		pShaderManager->setVec3Value("material.diffuseColor", diffuseColor);
		pShaderManager->setVec3Value("material.specularColor", specularColor);
		pShaderManager->setFloatValue("material.shininess", shininess);
	}
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	DestroyGLTextures();

	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	stbi_set_flip_vertically_on_load(true);

	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	if (image)
	{
		std::cout << "Successfully loaded image: " << filename
			<< ", width: " << width
			<< ", height: " << height
			<< ", channels: " << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		if (colorChannels == 3)
		{
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		}
		else if (colorChannels == 4)
		{
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		}
		else
		{
			std::cout << "Not implemented to handle image with "
				<< colorChannels << " channels" << std::endl;
			stbi_image_free(image);
			return false;
		}

		glGenerateMipmap(GL_TEXTURE_2D);

		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0);

		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image: " << filename << std::endl;
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots. There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glDeleteTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
		{
			index++;
		}
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
		{
			index++;
		}
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;

	while ((index < static_cast<int>(m_objectMaterials.size())) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(bFound);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	scale = glm::scale(scaleXYZ);

	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));

	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setBoolValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/***********************************************************
 *  LoadSceneTextures()
 *
 *  This method loads the textures used in the scene.
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	CreateGLTexture("../../Utilities/textures/rusticwood.jpg", "wood");
	CreateGLTexture("../../Utilities/textures/screen.jpg", "screen");
	CreateGLTexture("../../Utilities/textures/stainless.jpg", "metal");

	BindGLTextures();
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes and textures in memory to support the 3D scene
 *  rendering.
 ***********************************************************/
void SceneManager::PrepareScene()
{
	LoadSceneTextures();

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by
 *  transforming and drawing the basic 3D shapes.
 ***********************************************************/
void SceneManager::RenderScene()
{
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseLightingName, true);

		SetLightSource(
			m_pShaderManager,
			0,
			glm::vec3(3.0f, 4.0f, 3.0f),
			glm::vec3(0.45f, 0.45f, 0.45f),
			glm::vec3(0.75f, 0.75f, 0.75f),
			glm::vec3(0.30f, 0.30f, 0.30f),
			16.0f,
			0.18f);

		SetLightSource(
			m_pShaderManager,
			1,
			glm::vec3(-2.0f, 2.5f, -2.0f),
			glm::vec3(0.25f, 0.25f, 0.25f),
			glm::vec3(0.30f, 0.30f, 0.30f),
			glm::vec3(0.10f, 0.10f, 0.10f),
			8.0f,
			0.05f);

		SetLightSource(
			m_pShaderManager,
			2,
			glm::vec3(0.0f, 0.0f, 0.0f),
			glm::vec3(0.0f, 0.0f, 0.0f),
			glm::vec3(0.0f, 0.0f, 0.0f),
			glm::vec3(0.0f, 0.0f, 0.0f),
			1.0f,
			0.0f);

		SetLightSource(
			m_pShaderManager,
			3,
			glm::vec3(0.0f, 0.0f, 0.0f),
			glm::vec3(0.0f, 0.0f, 0.0f),
			glm::vec3(0.0f, 0.0f, 0.0f),
			glm::vec3(0.0f, 0.0f, 0.0f),
			1.0f,
			0.0f);
	}

	// Desk surface
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetMaterialValues(
		m_pShaderManager,
		glm::vec3(0.45f, 0.36f, 0.26f),
		0.38f,
		glm::vec3(0.78f, 0.64f, 0.46f),
		glm::vec3(0.22f, 0.22f, 0.22f),
		10.0f);
	SetShaderTexture("wood");
	SetTextureUVScale(3.0f, 3.0f);
	m_basicMeshes->DrawPlaneMesh();

	// Monitor body
	scaleXYZ = glm::vec3(4.0f, 2.3f, 0.25f);
	positionXYZ = glm::vec3(0.0f, 2.05f, 0.0f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_pShaderManager->setBoolValue("bUseTexture", false);
	SetMaterialValues(
		m_pShaderManager,
		glm::vec3(0.18f, 0.18f, 0.18f),
		0.38f,
		glm::vec3(0.30f, 0.30f, 0.30f),
		glm::vec3(0.12f, 0.12f, 0.12f),
		6.0f);
	SetShaderColor(0.22f, 0.22f, 0.22f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// Monitor screen
	scaleXYZ = glm::vec3(3.25f, 1.8f, 0.04f);
	positionXYZ = glm::vec3(0.0f, 2.05f, 0.14f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_pShaderManager->setBoolValue("bUseTexture", false);
	SetMaterialValues(
		m_pShaderManager,
		glm::vec3(0.28f, 0.28f, 0.28f),
		0.35f,
		glm::vec3(0.38f, 0.38f, 0.38f),
		glm::vec3(0.18f, 0.18f, 0.18f),
		10.0f);
	SetShaderColor(0.40f, 0.40f, 0.40f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// Monitor stand
	scaleXYZ = glm::vec3(0.22f, 0.95f, 0.18f);
	positionXYZ = glm::vec3(0.0f, 0.52f, -0.02f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_pShaderManager->setBoolValue("bUseTexture", true);
	SetMaterialValues(
		m_pShaderManager,
		glm::vec3(0.22f, 0.22f, 0.24f),
		0.32f,
		glm::vec3(0.62f, 0.62f, 0.67f),
		glm::vec3(0.50f, 0.50f, 0.52f),
		18.0f);
	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// Monitor base
	scaleXYZ = glm::vec3(1.3f, 0.15f, 1.8f);
	positionXYZ = glm::vec3(0.0f, 0.08f, 0.0f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_pShaderManager->setBoolValue("bUseTexture", true);
	SetMaterialValues(
		m_pShaderManager,
		glm::vec3(0.22f, 0.22f, 0.24f),
		0.32f,
		glm::vec3(0.62f, 0.62f, 0.67f),
		glm::vec3(0.50f, 0.50f, 0.52f),
		18.0f);
	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// Keyboard base
	scaleXYZ = glm::vec3(3.0f, 0.12f, 1.2f);
	positionXYZ = glm::vec3(0.0f, 0.06f, 2.0f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_pShaderManager->setBoolValue("bUseTexture", false);
	SetMaterialValues(
		m_pShaderManager,
		glm::vec3(0.15f, 0.15f, 0.15f),
		0.35f,
		glm::vec3(0.25f, 0.25f, 0.25f),
		glm::vec3(0.08f, 0.08f, 0.08f),
		6.0f);
	SetShaderColor(0.18f, 0.18f, 0.18f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// Keyboard keys row 1
	m_pShaderManager->setBoolValue("bUseTexture", false);
	SetMaterialValues(
		m_pShaderManager,
		glm::vec3(0.25f, 0.25f, 0.25f),
		0.30f,
		glm::vec3(0.35f, 0.35f, 0.35f),
		glm::vec3(0.10f, 0.10f, 0.10f),
		4.0f);

	for (int i = 0; i < 8; i++)
	{
		scaleXYZ = glm::vec3(0.22f, 0.05f, 0.22f);
		positionXYZ = glm::vec3(-1.2f + (i * 0.35f), 0.13f, 1.8f);

		SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
		SetShaderColor(0.35f, 0.35f, 0.35f, 1.0f);
		m_basicMeshes->DrawBoxMesh();
	}

	// Keyboard keys row 2
	for (int i = 0; i < 7; i++)
	{
		scaleXYZ = glm::vec3(0.22f, 0.05f, 0.22f);
		positionXYZ = glm::vec3(-1.0f + (i * 0.35f), 0.13f, 2.1f);

		SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
		SetShaderColor(0.35f, 0.35f, 0.35f, 1.0f);
		m_basicMeshes->DrawBoxMesh();
	}

	// Keyboard keys row 3
	for (int i = 0; i < 8; i++)
	{
		scaleXYZ = glm::vec3(0.22f, 0.05f, 0.22f);
		positionXYZ = glm::vec3(-1.2f + (i * 0.35f), 0.13f, 2.4f);

		SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
		SetShaderColor(0.35f, 0.35f, 0.35f, 1.0f);
		m_basicMeshes->DrawBoxMesh();
	}

	// Mouse body
	scaleXYZ = glm::vec3(0.4f, 0.08f, 0.6f);
	positionXYZ = glm::vec3(2.2f, 0.06f, 2.0f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_pShaderManager->setBoolValue("bUseTexture", true);
	SetMaterialValues(
		m_pShaderManager,
		glm::vec3(0.22f, 0.22f, 0.24f),
		0.32f,
		glm::vec3(0.62f, 0.62f, 0.67f),
		glm::vec3(0.50f, 0.50f, 0.52f),
		18.0f);
	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// Mouse buttons
	scaleXYZ = glm::vec3(0.18f, 0.02f, 0.20f);
	positionXYZ = glm::vec3(2.1f, 0.11f, 1.93f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.22f, 0.22f, 0.22f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	positionXYZ = glm::vec3(2.3f, 0.11f, 1.93f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawBoxMesh();
}